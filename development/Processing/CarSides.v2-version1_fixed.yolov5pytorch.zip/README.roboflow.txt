
CarSides - v2 Version1_Fixed
==============================

This dataset was exported via roboflow.ai on August 29, 2021 at 12:04 PM GMT

It includes 135 images.
CarSides are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


