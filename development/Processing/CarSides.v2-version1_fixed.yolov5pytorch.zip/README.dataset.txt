# undefined > Version1_Fixed
https://public.roboflow.ai/object-detection/undefined

Provided by undefined
License: ODbL v1.0

undefined